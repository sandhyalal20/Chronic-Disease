```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
from sklearn import metrics
from sklearn import svm
from sklearn.model_selection import train_test_split
```


```python
data = pd.read_csv(r'C:\Users\ELCOT\Desktop\heart.csv')
```


```python
data.shape
```




    (731, 14)




```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalach</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>52</td>
      <td>1</td>
      <td>0</td>
      <td>125</td>
      <td>212</td>
      <td>0</td>
      <td>1</td>
      <td>168</td>
      <td>0</td>
      <td>1.0</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>53</td>
      <td>1</td>
      <td>0</td>
      <td>140</td>
      <td>203</td>
      <td>1</td>
      <td>0</td>
      <td>155</td>
      <td>1</td>
      <td>3.1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>70</td>
      <td>1</td>
      <td>0</td>
      <td>145</td>
      <td>174</td>
      <td>0</td>
      <td>1</td>
      <td>125</td>
      <td>1</td>
      <td>2.6</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>61</td>
      <td>1</td>
      <td>0</td>
      <td>148</td>
      <td>203</td>
      <td>0</td>
      <td>1</td>
      <td>161</td>
      <td>0</td>
      <td>0.0</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>62</td>
      <td>0</td>
      <td>0</td>
      <td>138</td>
      <td>294</td>
      <td>1</td>
      <td>1</td>
      <td>106</td>
      <td>0</td>
      <td>1.9</td>
      <td>1</td>
      <td>3</td>
      <td>2</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalach</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>731.000000</td>
      <td>731.000000</td>
      <td>731.000000</td>
      <td>731.000000</td>
      <td>731.000000</td>
      <td>731.000000</td>
      <td>731.000000</td>
      <td>731.000000</td>
      <td>731.000000</td>
      <td>731.000000</td>
      <td>731.000000</td>
      <td>731.000000</td>
      <td>731.000000</td>
      <td>731.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>59.116279</td>
      <td>0.677155</td>
      <td>0.893297</td>
      <td>134.526676</td>
      <td>252.088919</td>
      <td>0.181943</td>
      <td>0.492476</td>
      <td>144.444596</td>
      <td>0.376197</td>
      <td>1.232148</td>
      <td>1.329685</td>
      <td>0.887825</td>
      <td>2.359781</td>
      <td>0.447332</td>
    </tr>
    <tr>
      <th>std</th>
      <td>5.659652</td>
      <td>0.467884</td>
      <td>1.054460</td>
      <td>18.459145</td>
      <td>53.117281</td>
      <td>0.386061</td>
      <td>0.539798</td>
      <td>22.378883</td>
      <td>0.484762</td>
      <td>1.208086</td>
      <td>0.614378</td>
      <td>1.010087</td>
      <td>0.656242</td>
      <td>0.497559</td>
    </tr>
    <tr>
      <th>min</th>
      <td>50.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>94.000000</td>
      <td>126.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>71.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>55.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>120.000000</td>
      <td>216.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>130.000000</td>
      <td>0.000000</td>
      <td>0.100000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>58.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>132.000000</td>
      <td>245.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>147.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>63.000000</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>145.000000</td>
      <td>283.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>161.000000</td>
      <td>1.000000</td>
      <td>1.900000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>3.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>77.000000</td>
      <td>1.000000</td>
      <td>3.000000</td>
      <td>200.000000</td>
      <td>564.000000</td>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>195.000000</td>
      <td>1.000000</td>
      <td>6.200000</td>
      <td>2.000000</td>
      <td>4.000000</td>
      <td>3.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.pairplot(data=data[['age','sex','cp','trestbps','target']],hue='target')
```




    <seaborn.axisgrid.PairGrid at 0xcfa09b8>




![png](output_6_1.png)



```python
sns.pairplot(data=data[['exang','oldpeak','slope','target']],hue='target')
```




    <seaborn.axisgrid.PairGrid at 0xe08c448>




![png](output_7_1.png)



```python
train = data.drop('target',axis = 1)
train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalach</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>52</td>
      <td>1</td>
      <td>0</td>
      <td>125</td>
      <td>212</td>
      <td>0</td>
      <td>1</td>
      <td>168</td>
      <td>0</td>
      <td>1.0</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>53</td>
      <td>1</td>
      <td>0</td>
      <td>140</td>
      <td>203</td>
      <td>1</td>
      <td>0</td>
      <td>155</td>
      <td>1</td>
      <td>3.1</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>70</td>
      <td>1</td>
      <td>0</td>
      <td>145</td>
      <td>174</td>
      <td>0</td>
      <td>1</td>
      <td>125</td>
      <td>1</td>
      <td>2.6</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>61</td>
      <td>1</td>
      <td>0</td>
      <td>148</td>
      <td>203</td>
      <td>0</td>
      <td>1</td>
      <td>161</td>
      <td>0</td>
      <td>0.0</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>62</td>
      <td>0</td>
      <td>0</td>
      <td>138</td>
      <td>294</td>
      <td>1</td>
      <td>1</td>
      <td>106</td>
      <td>0</td>
      <td>1.9</td>
      <td>1</td>
      <td>3</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
target = data.target
target.head()
```




    0    0
    1    0
    2    0
    3    0
    4    0
    Name: target, dtype: int64




```python
x_train,x_test,y_train,y_test = train_test_split(train,target,test_size = 0.3,random_state = 109)
```


```python
print("X_train_size ==>",x_train.shape)
print("Y_train_size ==>",y_train.shape)
print("X_test_size ==>",x_test.shape)
print("Y_test_size ==>",y_test.shape)
```

    X_train_size ==> (511, 13)
    Y_train_size ==> (511,)
    X_test_size ==> (220, 13)
    Y_test_size ==> (220,)
    


```python
clf = svm.SVC(kernel = 'linear')
clf.fit(x_train,y_train)
y_pred = clf.predict(x_test)
```


```python
print("ACCURACY :",metrics.accuracy_score(y_test,y_pred))
```

    ACCURACY : 0.7909090909090909
    


```python
print("PRECISION :",metrics.precision_score(y_test,y_pred))
```

    PRECISION : 0.6964285714285714
    


```python
print("RECALL :",metrics.recall_score(y_test,y_pred))
```

    RECALL : 0.8666666666666667
    


```python
x_train,x_test,y_train,y_test = train_test_split(train,target,test_size=0.30,random_state=10)
```


```python
from sklearn.impute import SimpleImputer
fill_values = SimpleImputer(missing_values = 0,strategy='mean',verbose=0)
x_train = fill_values.fit_transform(x_train)
x_test = fill_values.fit_transform(x_test)
```


```python
from sklearn.ensemble import RandomForestClassifier
random_forest_mode1 = RandomForestClassifier(random_state=10)

random_forest_mode1.fit(x_train,y_train.ravel())
```




    RandomForestClassifier(random_state=10)




```python
predict_train_data = random_forest_mode1.predict(x_test)

from sklearn import metrics

print("Accuracy: {0}".format(metrics.accuracy_score(y_test,predict_train_data)))
```

    Accuracy: 0.9863636363636363
    


```python
from sklearn.naive_bayes import GaussianNB

gnb = GaussianNB()

gnb.fit(x_train,y_train.ravel())

y_pred = gnb.predict(x_test)
```


```python
from sklearn import metrics

print("ACCURACY : {0}".format(metrics.accuracy_score(y_test,y_pred)))
```

    ACCURACY : 0.7772727272727272
    


```python
from sklearn.tree import DecisionTreeClassifier

classifier = DecisionTreeClassifier()

classifier = classifier.fit(x_train,y_train)
```


```python
y_pred = classifier.predict(x_test)
print("ACCURACY : {0}".format(metrics.accuracy_score(y_test,y_pred)))
```

    ACCURACY : 0.9727272727272728
    


```python

```
